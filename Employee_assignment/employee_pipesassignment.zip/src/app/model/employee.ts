export interface IEmployee{
    employeeId : number,
    firstName : string,
    lastName : string,
    salary : number,
    dob : string,
    email : string
}