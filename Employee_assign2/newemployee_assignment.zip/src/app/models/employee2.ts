export interface EmployeeDet{
    id : number,
    employee_name : string,
    employee_salary : string,
    salary : number,
    employee_age : string,
    profile_image : string
}