import { Component, OnInit} from '@angular/core';
import { EmployeeDet } from '../models/employee2';
import { EmployeeService } from '../services/employee.service';

@Component({
    selector:'app-newemployee',
    templateUrl: './newemployee.component.html',
    styleUrls: ['./newemployee.component.css']
})

export class NewEmployee implements OnInit{

    //constructor(private employeeService:EmployeeService){}
    ngOnInit(): void {
        
    }

}